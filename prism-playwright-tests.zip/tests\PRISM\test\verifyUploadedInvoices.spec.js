'use strict';

/**
 * PRISM – Full End-to-End Workflow Application Spec
 *
 * Phases Covered:
 * 1. Login & Dashboard navigation
 * 2. Upload Invoice (Select Job Name, select PDFs, submit to processing queue)
 * 3. Review Invoices (Find Job in table, View Details, verify all files appear)
 * 4. Invoice Validation (Open Review screen, check extracted field error states, mark as Completed)
 * 4b. PDF Cross-Verification (Compare PRISM auto-extracted values vs raw PDF text)
 * 5. Mark invoice status (Completed / Rejected)
 */

const { test, expect }          = require('@playwright/test');
const { LoginPage }             = require('../pages/LoginPage');
const { DashboardPage }         = require('../pages/DashboardPage');
const { UploadInvoicePage }     = require('../pages/UploadInvoicePage');
const { ReviewInvoicePage }     = require('../pages/ReviewInvoicePage');
const { InvoiceValidationPage } = require('../pages/InvoiceValidationPage');
const { loadFilesFromFolder }   = require('../utils/fileHelper');
const { extractPDFFields, extractFieldsFromText } = require('../utils/pdfFieldExtractor');
const { ocrExtractFromPDF }                       = require('../utils/ocrPdfReader');
const path = require('path');

const EMAIL     = process.env.PRISM_EMAIL    ?? 'business@prism.ai';
const PASSWORD  = process.env.PRISM_PASSWORD ?? 'Business@123';
const FILES_DIR = path.resolve(__dirname, '..', '..', 'temp');

// ─────────────────────────────────────────────────────────────────────────────

test.describe('PRISM – Full Application E2E Cycle', () => {

  let loginPage, dashboardPage, uploadPage, reviewPage, validationPage;
  let generatedJobName = '';
  let filePaths        = [];
  let uploadedFileNames = [];

  test.beforeEach(async ({ page }) => {
    loginPage      = new LoginPage(page);
    dashboardPage  = new DashboardPage(page);
    uploadPage     = new UploadInvoicePage(page);
    reviewPage     = new ReviewInvoicePage(page);
    validationPage = new InvoiceValidationPage(page);

    await loginPage.goto();
    await loginPage.login(EMAIL, PASSWORD);
    await dashboardPage.waitForDashboard();
  });

  // ───────────────────────────────────────────────────────────────────────────
  // TC01_Master  Upload → Review → Validate → PDF Cross-Verify → Mark Status
  // ───────────────────────────────────────────────────────────────────────────
  test('TC01_Master – Execute full Upload, Review, Validation and PDF Cross-Verification Flow', async ({ page }) => {

    // 7-minute budget to cover upload + OCR queue + field verification
    test.setTimeout(420_000);

    // ──────────────────────────────────────────────────────────────────────
    // Step 1: Upload the files
    // ──────────────────────────────────────────────────────────────────────
    filePaths         = loadFilesFromFolder(FILES_DIR).slice(0, 1);
    uploadedFileNames = filePaths.map(fp => path.basename(fp));

    await dashboardPage.clickUploadInvoice();
    await uploadPage.waitForUploadForm();

    // Build a UNIQUE job name for every run so the search on the Review
    // Invoice page always finds THIS run's job — never a stale older one.
    // Format: <first 6 chars of file name>-<last 6 digits of timestamp>
    // e.g. "100004-988123"  (≤ 14 chars — within PRISM's ~15 char limit)
    const fileBaseName   = path.basename(filePaths[0], path.extname(filePaths[0])); // e.g. "1000043601 -BSLJMC-PT-08"
    const runSuffix      = String(Date.now()).slice(-6);                             // e.g. "988123"
    generatedJobName     = `${fileBaseName.slice(0, 6).trim()}-${runSuffix}`;       // e.g. "100004-988123"
    console.log(`[Step 1] Using job name: "${generatedJobName}" (unique per run, derived from: "${uploadedFileNames[0]}")`);
    await uploadPage.enterJobName(generatedJobName);
    await uploadPage.uploadMultipleFiles(filePaths);

    await uploadPage.clickUploadAndProcess();

    // ── Wait for upload success (multi-signal, resilient) ─────────────────────
    console.log('[TC01_Master] Waiting for upload success signal...');
    let uploadSuccess = false;
    const uploadDeadline = Date.now() + 20_000;
    while (Date.now() < uploadDeadline && !uploadSuccess) {
      const [toastVisible, urlChanged, btnGone] = await Promise.all([
        uploadPage.successMessage.isVisible().catch(() => false),
        Promise.resolve(/dashboard|review|job/i.test(page.url())),
        uploadPage.uploadAndProcessButton.isHidden().catch(() => false),
      ]);
      if (toastVisible || urlChanged || btnGone) {
        uploadSuccess = true;
        console.log(`[TC01_Master] ✅ Upload confirmed (toast=${toastVisible} url=${urlChanged} btnGone=${btnGone})`);
      } else {
        await page.waitForTimeout(1000);
      }
    }
    if (!uploadSuccess) {
      console.warn('[TC01_Master] ⚠️  No immediate upload signal — proceeding to review check (upload may still have worked).');
    }

    // ──────────────────────────────────────────────────────────────────────
    // Step 2: Navigate to Review Invoices → Search by Job Name → Click View
    // ──────────────────────────────────────────────────────────────────────
    //   Flow:
    //   a. Go to /review page
    //   b. Search by the GENERATED JOB NAME (e.g. "E2E-15146861")
    //   c. Find the matching job row → click "View" (row may still show Processing)
    //   d. Inside job detail: wait until status becomes "Under Review"
    //   e. Click "Actions → Review"
    // ──────────────────────────────────────────────────────────────────────
    console.log(`\n[Step 2] Navigating to Review Invoices.`);
    console.log(`         Searching for job name: "${generatedJobName}" (same as uploaded file name prefix)`);

    await reviewPage.goto();
    await expect(page).toHaveURL(/\/review/i);
    // Search using the file-name-derived job name — now guaranteed to match the row
    await reviewPage.searchByJobName(generatedJobName);
    await reviewPage.clickViewForJob(generatedJobName);

    const allFilesVisible = await reviewPage.areUploadedFilesVisible(uploadedFileNames);
    if (!allFilesVisible) {
      console.log('[Step 2] NOTE: File not yet visible in job detail. The Review button loop will wait for processing to complete...');
    }

    // ──────────────────────────────────────────────────────────────────────
    // Step 3: Wait for "Under Review" status → Click "Review"
    // ──────────────────────────────────────────────────────────────────────
    console.log(`\n[Step 3] Waiting for status "Under Review" then clicking Review button...`);
    await reviewPage.clickReviewOnFirstFile(generatedJobName);
    await validationPage.waitForValidationScreen();

    // ──────────────────────────────────────────────────────────────────────
    // Step 4: Read all 59 PRISM extracted fields from the right panel
    // ──────────────────────────────────────────────────────────────────────
    console.log('\n[Step 4] Evaluating extracted field states from PRISM right panel...');
    const { shouldComplete, details } = await validationPage.evaluateFieldsForCompletion();

    console.log('\n===== PRISM Field Evaluation (59 fields) =====');
    for (const d of details) {
      const icon =
        d.decision.includes('VALID')    ? '✅' :
        d.decision.includes('MISMATCH') ? '❌' : '⏭️ ';
      console.log(`  ${icon}  ${d.label}: "${d.value}" → ${d.decision}`);
    }
    console.log('===============================================\n');

    // ──────────────────────────────────────────────────────────────────────
    // Step 4b: PDF Cross-Verification — compare PRISM values vs raw PDF
    //
    //   The uploaded PDF is read via two-stage pipeline:
    //     Stage 1 → pdf-parse  (fast, text-layer PDFs only)
    //     Stage 2 → OCR        (Playwright renders PDF → Tesseract reads image)
    //
    //   Each PRISM field extracted from the right panel is compared against
    //   the corresponding value found in the PDF text.
    //
    //   Results:
    //     ✅ MATCH     → PRISM extracted correctly
    //     ❌ MISMATCH  → PRISM value differs from PDF source
    //     ⏭️  NOT FOUND → Field value couldn't be located in PDF text
    // ──────────────────────────────────────────────────────────────────────
    console.log('\n[Step 4b] PDF Cross-Verification started...');
    console.log(`          PDF file: ${path.basename(filePaths[0])}\n`);

    const reviewedPdfPath = filePaths[0];
    let pdfFieldMap = new Map();

    // Stage 1: pdf-parse (text-layer PDFs only — fast)
    try {
      pdfFieldMap = await extractPDFFields(reviewedPdfPath);
      if (pdfFieldMap.size > 0) {
        console.log(`[Stage 1 – pdf-parse] ✅ Extracted ${pdfFieldMap.size} field(s) from PDF text layer.`);
      } else {
        console.log('[Stage 1 – pdf-parse] No text layer found. Falling back to OCR...');
      }
    } catch (err) {
      console.warn(`[Stage 1 – pdf-parse] Error: ${err.message}. Falling back to OCR...`);
    }

    // Stage 2: OCR fallback (headless cannot render PDFs, so a headed browser is used)
    if (pdfFieldMap.size === 0) {
      console.log('[Stage 2 – OCR] Launching browser to render PDF → Tesseract extracts text...');
      console.log('  ⏳ First run downloads Tesseract language data (~24 MB) — please wait.\n');
      try {
        const ocrText = await ocrExtractFromPDF(reviewedPdfPath, page.context(), {
          maxPages:      3,
          renderDelayMs: 2500,
          debug:         true,
        });
        if (ocrText && ocrText.trim().length > 20) {
          pdfFieldMap = extractFieldsFromText(ocrText);
          console.log(`[Stage 2 – OCR] ✅ ${pdfFieldMap.size} field(s) identified from OCR text.`);
        } else {
          console.warn('[Stage 2 – OCR] OCR produced no usable text from this PDF page.');
        }
      } catch (err) {
        console.warn(`[Stage 2 – OCR] Failed: ${err.message}`);
      }
    }

    // Cross-verify PRISM fields vs PDF
    if (pdfFieldMap.size === 0) {
      console.warn(
        '\n⚠️  PDF Cross-Verification SKIPPED\n' +
        '   Reason: Neither pdf-parse nor OCR could extract readable text from this PDF.\n' +
        '   PRISM field evaluation (Step 4) remains the authoritative pass/fail check.\n'
      );
    } else {
      const crossVerifyReport = await validationPage.crossVerifyWithPDF(pdfFieldMap);

      const matched    = crossVerifyReport.filter(r => r.result.includes('MATCH ✅'));
      const mismatched = crossVerifyReport.filter(r => r.result.includes('MISMATCH'));
      const notFound   = crossVerifyReport.filter(r => r.result.includes('NOT FOUND'));

      // Print the full comparison table
      console.log('\n╔══════════════════════════════════════════════════════════════════╗');
      console.log('║          PDF Cross-Verification Report                          ║');
      console.log('╚══════════════════════════════════════════════════════════════════╝\n');

      console.log('  ─── MATCHED fields (PRISM = PDF) ───────────────────────────────');
      if (matched.length === 0) {
        console.log('  (none)');
      } else {
        for (const r of matched) {
          console.log(`  ✅  ${r.label}`);
          console.log(`       PRISM : "${r.prismValue}"`);
          console.log(`       PDF   : "${r.pdfValue}"\n`);
        }
      }

      console.log('  ─── MISMATCHED fields (PRISM ≠ PDF) ────────────────────────────');
      if (mismatched.length === 0) {
        console.log('  (none — all verifiable fields matched! ✅)');
      } else {
        for (const r of mismatched) {
          console.log(`  ❌  ${r.label}`);
          console.log(`       PRISM : "${r.prismValue}"`);
          console.log(`       PDF   : "${r.pdfValue}"\n`);
        }
      }

      console.log('  ─── NOT FOUND in PDF (field exists in PRISM but not in PDF text)');
      if (notFound.length === 0) {
        console.log('  (none)');
      } else {
        for (const r of notFound) {
          console.log(`  ⏭️   ${r.label}: PRISM="${r.prismValue}"`);
        }
      }

      console.log(`\n  Summary: ✅ ${matched.length} matched | ❌ ${mismatched.length} mismatched | ⏭️  ${notFound.length} not found in PDF`);
      console.log('══════════════════════════════════════════════════════════════════\n');

      // Hard assertion: mismatched fields must be 0
      // OCR noise (e.g. "BULTWELL" vs "BUILTWELL") is expected but flagged here.
      expect(
        mismatched.length,
        `PDF Cross-Verification failed: ${mismatched.length} field(s) extracted by PRISM do NOT match the source PDF.\n` +
        mismatched.map(r => `  ❌ ${r.label}: PRISM="${r.prismValue}" vs PDF="${r.pdfValue}"`).join('\n')
      ).toBe(0);
    }


    // ──────────────────────────────────────────────────────────────────────
    // Step 5: Mark Status Based on PRISM Field Evaluation (Step 4)
    // ──────────────────────────────────────────────────────────────────────
    if (shouldComplete) {
      console.log('All populated fields are valid (no critical errors). Marking invoice as COMPLETED ✅');
      await validationPage.markAsCompleted();
    } else {
      console.warn('Critical field errors found. Marking invoice as REJECTED ❌');
      await validationPage.markAsRejected();
    }
  });
});

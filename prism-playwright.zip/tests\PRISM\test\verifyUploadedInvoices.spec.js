'use strict';

/**
 * PRISM – Full End-to-End Workflow Application Spec
 *
 * Phases Covered:
 * 1. Login & Dashboard navigation
 * 2. Upload Invoice (Select Job Name, select PDFs, submit to processing queue)
 * 3. Review Invoices (Find Job in table, View Details, verify all files appear)
 * 4. Invoice Validation (Open Review screen, check extracted field error states, mark as Completed)
 * 4b. PDF Cross-Verification (Compare PRISM auto-extracted values vs raw PDF text)
 * 5. Mark invoice status (Completed / Rejected)
 */

const { test, expect }          = require('@playwright/test');
const { LoginPage }             = require('../pages/LoginPage');
const { DashboardPage }         = require('../pages/DashboardPage');
const { UploadInvoicePage }     = require('../pages/UploadInvoicePage');
const { ReviewInvoicePage }     = require('../pages/ReviewInvoicePage');
const { InvoiceValidationPage } = require('../pages/InvoiceValidationPage');
const { loadFilesFromFolder }   = require('../utils/fileHelper');
const { extractPDFFields, extractFieldsFromText } = require('../utils/pdfFieldExtractor');
const { ocrExtractFromPDF }                       = require('../utils/ocrPdfReader');
const path = require('path');

const EMAIL     = process.env.PRISM_EMAIL    ?? 'business@prism.ai';
const PASSWORD  = process.env.PRISM_PASSWORD ?? 'Business@123';
const FILES_DIR = path.resolve(__dirname, '..', '..', 'temp');

// ─────────────────────────────────────────────────────────────────────────────

test.describe('PRISM – Full Application E2E Cycle', () => {

  let loginPage, dashboardPage, uploadPage, reviewPage, validationPage;
  let generatedJobName = '';
  let filePaths        = [];
  let uploadedFileNames = [];

  test.beforeEach(async ({ page }) => {
    loginPage      = new LoginPage(page);
    dashboardPage  = new DashboardPage(page);
    uploadPage     = new UploadInvoicePage(page);
    reviewPage     = new ReviewInvoicePage(page);
    validationPage = new InvoiceValidationPage(page);

    await loginPage.goto();
    await loginPage.login(EMAIL, PASSWORD);
    await dashboardPage.waitForDashboard();
  });

  // ───────────────────────────────────────────────────────────────────────────
  // TC01_Master  Upload → Review → Validate → PDF Cross-Verify → Mark Status
  // ───────────────────────────────────────────────────────────────────────────
  test('TC01_Master – Execute full Upload, Review, Validation and PDF Cross-Verification Flow', async ({ page }) => {

    // 7-minute budget to cover upload + OCR queue + field verification
    test.setTimeout(420_000);

    // ──────────────────────────────────────────────────────────────────────
    // Step 1: Upload the files
    // ──────────────────────────────────────────────────────────────────────
    filePaths         = loadFilesFromFolder(FILES_DIR);
    uploadedFileNames = filePaths.map(fp => path.basename(fp));

    await dashboardPage.clickUploadInvoice();
    await uploadPage.waitForUploadForm();

    // Keep job name short (≤ 15 chars) — PRISM truncates long names in its DB
    generatedJobName = `E2E-${String(Date.now()).slice(-8)}`;
    await uploadPage.enterJobName(generatedJobName);
    await uploadPage.uploadMultipleFiles(filePaths);

    await uploadPage.clickUploadAndProcess();
    await expect(uploadPage.successMessage).toBeVisible({ timeout: 60_000 });

    // ──────────────────────────────────────────────────────────────────────
    // Step 2: Navigate to Review Invoices & Verify Table
    // ──────────────────────────────────────────────────────────────────────
    await reviewPage.goto();
    await expect(page).toHaveURL(/\/review/i);
    await reviewPage.searchByJobName(generatedJobName);
    await reviewPage.clickAndViewJob(generatedJobName);

    const allFilesVisible = await reviewPage.areUploadedFilesVisible(uploadedFileNames);
    if (!allFilesVisible) {
      console.log('NOTICE: Some files are still processing. Proceeding to validate the first available file...');
    }

    // ──────────────────────────────────────────────────────────────────────
    // Step 3: Click Review on the First File
    // ──────────────────────────────────────────────────────────────────────
    await reviewPage.clickReviewOnFirstFile(generatedJobName);
    await validationPage.waitForValidationScreen();

    // ──────────────────────────────────────────────────────────────────────
    // Step 4: Evaluate the Extracted Field Error States (PRISM internal check)
    // ──────────────────────────────────────────────────────────────────────
    console.log('\nEvaluating extracted field states from PRISM right panel...');
    const { shouldComplete, details } = await validationPage.evaluateFieldsForCompletion();

    console.log('\n===== Field Evaluation Results =====');
    for (const d of details) {
      const icon =
        d.decision.includes('VALID')    ? '✅' :
        d.decision.includes('MISMATCH') ? '❌' : '⏭️ ';
      console.log(`  ${icon}  ${d.label}: "${d.value}" → ${d.decision}`);
    }
    console.log('=====================================\n');

    // ──────────────────────────────────────────────────────────────────────
    // Step 4b: PDF Cross-Verification  (two-stage pipeline)
    //
    //   Stage 1 – pdf-parse  : fast; works only on text-layer PDFs
    //   Stage 2 – OCR        : Playwright renders PDF in browser → screenshot
    //                          → Tesseract.js reads text from the image
    //                          (handles scanned / image-only PDFs ✅)
    //
    // Result for each PRISM field:
    //   ✅ PDF MATCH     → PRISM correctly extracted the value
    //   ❌ PDF MISMATCH  → PRISM value differs from what is in the PDF
    //   ⏭️  PDF NOT FOUND → Field not found in PDF text at all
    //
    // Mismatches are WARNINGS only — pass/fail is driven by Step 4 above.
    // ──────────────────────────────────────────────────────────────────────
    console.log('\n─── Step 4b: PDF Cross-Verification (pdf-parse → OCR fallback) ────');

    const reviewedPdfPath = filePaths[0];
    console.log(`PDF to verify: ${path.basename(reviewedPdfPath)}`);

    let pdfFieldMap = new Map();

    // ── Stage 1: pdf-parse (text-based PDFs only) ─────────────────────────
    try {
      pdfFieldMap = await extractPDFFields(reviewedPdfPath);
      if (pdfFieldMap.size > 0) {
        console.log(`[Stage 1 – pdf-parse] ✅ Extracted ${pdfFieldMap.size} field(s) from PDF text.`);
      } else {
        console.log('[Stage 1 – pdf-parse] No text layer found. Moving to Stage 2 (OCR)...');
      }
    } catch (err) {
      console.warn(`[Stage 1 – pdf-parse] Error: ${err.message}. Moving to Stage 2 (OCR)...`);
    }

    // ── Stage 2: OCR fallback (Playwright browser render + Tesseract) ─────
    if (pdfFieldMap.size === 0) {
      console.log(
        '\n[Stage 2 – OCR] Opening PDF in browser for visual rendering...\n' +
        '  ⏳ First run downloads Tesseract language data (~24 MB) — please wait.'
      );
      try {
        const ocrText = await ocrExtractFromPDF(reviewedPdfPath, page.context(), {
          maxPages:      3,     // read up to 3 pages of the invoice
          renderDelayMs: 2500,
          debug:         true,  // ← prints raw OCR text; set false once patterns are tuned
        });

        if (ocrText && ocrText.trim().length > 20) {
          pdfFieldMap = extractFieldsFromText(ocrText);
          console.log(`[Stage 2 – OCR] ✅ ${pdfFieldMap.size} field(s) identified from OCR text.`);
        } else {
          console.warn('[Stage 2 – OCR] OCR produced no usable text from this PDF.');
        }
      } catch (err) {
        console.warn(`[Stage 2 – OCR] Failed: ${err.message}`);
      }
    }

    // ── Run cross-verification (or report that it couldn't run) ───────────
    if (pdfFieldMap.size === 0) {
      console.warn(
        '\n⚠️  PDF Cross-Verification SKIPPED:\n' +
        '   Neither pdf-parse nor OCR could extract text from this PDF.\n' +
        '   PRISM\'s own field evaluation (Step 4) remains the authoritative check.\n'
      );
    } else {
      const crossVerifyReport = await validationPage.crossVerifyWithPDF(pdfFieldMap);

      const matchCount    = crossVerifyReport.filter(r => r.result.includes('MATCH ✅')).length;
      const mismatchCount = crossVerifyReport.filter(r => r.result.includes('MISMATCH')).length;
      const notFoundCount = crossVerifyReport.filter(r => r.result.includes('NOT FOUND')).length;

      console.log(
        '\n📊 PDF Cross-Verification Summary:\n' +
        `   ✅ ${matchCount}  field(s) matched between PDF and PRISM\n` +
        `   ❌ ${mismatchCount}  field(s) mismatched (PRISM value differs from PDF)\n` +
        `   ⏭️  ${notFoundCount}  field(s) not found in PDF text\n`
      );

      if (mismatchCount > 0) {
        // Soft warning — test still passes; PRISM error-state is authoritative.
        // Uncomment to make mismatches hard-fail the test:
        // expect(mismatchCount, `${mismatchCount} field(s) mismatched`).toBe(0);
        console.warn(
          `⚠️  ${mismatchCount} PRISM field value(s) did NOT match the PDF.\n` +
          '   Review the cross-verification report above for details.\n' +
          '   The test still completes — pass/fail is based on PRISM error states.'
        );
      } else if (matchCount > 0) {
        console.log('✅ All verifiable PRISM field values match the PDF content!');
      }
    }

    // ──────────────────────────────────────────────────────────────────────
    // Step 5: Mark Status Based on PRISM Field Evaluation (Step 4)
    // ──────────────────────────────────────────────────────────────────────
    if (shouldComplete) {
      console.log('All populated fields are valid (no critical errors). Marking invoice as COMPLETED ✅');
      await validationPage.markAsCompleted();
    } else {
      console.warn('Critical field errors found. Marking invoice as REJECTED ❌');
      await validationPage.markAsRejected();
    }
  });
});
